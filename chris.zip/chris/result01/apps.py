from django.apps import AppConfig


class Result01Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'result01'
