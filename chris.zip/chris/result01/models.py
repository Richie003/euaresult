from django.db import models
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser
)
from datetime import datetime, timedelta
from django.core.exceptions import ValidationError
from django.conf import settings
from django.utils.timezone import now


class UserManager(BaseUserManager):
    def create_user(self, email, reg_no, tel, first_name, last_name, password):
        """
        Creates and saves a User with the given email and password.
        """
        if not email:
            raise ValueError('Users must have an email address')

        user = self.model(
            email=self.normalize_email(email),
            reg_no=reg_no,
            tel=tel,
            first_name=first_name,
            last_name=last_name
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_staffuser(self, email, reg_no, tel, first_name, last_name, password):
        """
        Creates and saves a staff user with the given email and password.
        """
        user = self.create_user(
            email=self.normalize_email(email),
            reg_no=reg_no,
            tel=tel,
            first_name=first_name,
            last_name=last_name,
            password=password,
        )
        user.staff = True
        user.save(using=self._db)
        return user

    def create_superuser(self, email, reg_no, tel, first_name, last_name, password):
        """
        Creates and saves a superuser with the given email and password.
        """
        user = self.create_user(
            email=self.normalize_email(email),
            reg_no=reg_no,
            tel=tel,
            first_name=first_name,
            last_name=last_name,
            password=password,
        )
        user.staff = True
        user.admin = True
        user.save(using=self._db)
        return user


def clean_reg(reg_no):
    if '/' not in reg_no:
        raise ValidationError('not a password')
    return reg_no


class User(AbstractBaseUser):
    objects = UserManager()
    email = models.EmailField(
        verbose_name='email address',
        max_length=255,
        unique=True,
    )
    # COLLEGES = (
    #     ('SCIENCES', 'SCIENCES'),
    #     ('HEALTH SCIENCES', 'HEALTH SCIENCES'),
    #     ('SOCIAL SCIENCES', 'SOCIAL SCIENCES'),
    #     ('MANAGEMENT SCIENCES', 'MANAGEMENT SCIENCES'),
    #     ('ART', 'ART')
    # )
    # college = models.CharField(max_length=30, default='', choices=COLLEGES)
    reg_no = models.CharField(default='', verbose_name='reg_no', unique=True, null=False, blank=False, max_length=30,
                              validators=[clean_reg])
    tel = models.CharField(default=54, null=False, blank=False, max_length=11)
    first_name = models.CharField(default='', blank=False, null=False, max_length=100)
    last_name = models.CharField(default='', max_length=100)
    active = models.BooleanField(default=True)
    staff = models.BooleanField(default=False)  # a admin user; non super-user
    admin = models.BooleanField(default=False)  # a superuser
    # notice the absence of a "Password field", that is built in.

    USERNAME_FIELD = 'reg_no'
    REQUIRED_FIELDS = ['email', 'first_name', 'last_name', 'tel']  # Email & Password are required by default.

    def get_full_name(self):
        # The user is identified by their email address
        return self.reg_no

    def get_short_name(self):
        # The user is identified by their email address
        return self.reg_no

    def __str__(self):  # __unicode__ on Python 2
        # concatenate = '%s %s' % (self.first_name, self.last_name)
        return self.reg_no

    def has_perms(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return True

    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return True

    def has_module_perms(self, app_label):
        """Does the user have permissions to view the app `app_label`?"""
        # Simplest possible answer: Yes, always
        return True

    @property
    def is_staff(self):
        """Is the user a member of staff?"""
        return self.staff

    @property
    def is_admin(self):
        """Is the user a admin member?"""
        return self.admin

    @property
    def is_active(self):
        """Is the user active?"""
        return self.active


# Create your models here.

class College(models.Model):
    my_college = models.CharField(default="", blank=True, null=True, max_length=100)

    def __str__(self):
        return str(self.my_college)


class Dept(models.Model):
    departments = (
        ("ECONOMICS", "ECONOMICS"),
        ("NURSING", "NURSING")
    )
    my_department = models.CharField(default="", max_length=200, null=False, blank=True)

    def __str__(self):
        return self.my_department


# class CollegeScience(models.Model):
#     student = models.ForeignKey(settings.AUTH_USER_MODEL, default=1, on_delete=models.CASCADE)
#     college = models.ManyToManyField(College)
#     department = models.ManyToManyField(Dept)
#     maths = models.IntegerField(blank=True, null=True, default=0)
#     bch = models.IntegerField(blank=True, null=True, default=0)
#     physics = models.IntegerField(blank=True, null=True, default=0)
#     csc101 = models.IntegerField(blank=True, null=True, default=0)
#     csc222 = models.IntegerField(blank=True, null=True, default=0)
#
#     def __str__(self):
#         return str(f"result for {self.department}")


class Department(models.Model):
    lists = (
        ("NURSING", "NURSING"),
        ("RADIOGRAPHY", "RADIOGRAPHY"),
        ("MEDICAL LABORATORY", "MEDICAL LABORATORY"),
        ("PHYSIOTHERAPHY", "PHYSIOTHERAPHY"),
        ("BIOTECHNOLOGY", "BIOTECHNOLOGY"),
        ("INDUSTRIAL CHEMISTRY", "INDUSTRIAL CHEMISTRY"),
        ("PETROLEUM ENGINEERING", "PETROLEUM ENGINEERING"),
        ("COMPUTER SCIENCE", "COMPUTER SCIENCE"),
        ("PHYSICS WITH ELECTRONICS", "PHYSICS WITH ELECTRONICS"),
        ("MATHEMATICS", "MATHEMATICS"),
        ("ECONOMICS", "ECONOMICS"),
        ("ACCOUNTING", "ACCOUNTING"),
        ("MASS COMMUNICATION", "MASS COMMUNICATION"),
        ("POLITICAL SCIENCE", "POLITICAL SCIENCE"),
        ("SOCIAL SCIENCE", "SOCIAL SCIENCE"),
    )
    dept = models.CharField(max_length=200, null=True, choices=lists)

    def __str__(self):
        return self.dept


def condition(param):
    if param == 'SCIENCES':
        default = 8
        return default
    else:
        default = 0
        return default


levels = (
    ("1", "1"),
    ("2", "2"),
    ("3", "3"),
    ("4", "4"),
)


class CourseModel(models.Model):
    choose = (
        ("Full-time", "Full-time"),
        ("Half-time", "Half-time")
    )
    colleges = (
        ("HEALTH SCIENCES", "HEALTH SCIENCES"),
        ("SCIENCES", "SCIENCES"),
        ("ARTS", "ARTS"),
        ("MANAGEMENT", "MANAGEMENT"),
        ("SOCIAL", "SOCIAL")
    )

    Registration_No = models.ForeignKey(settings.AUTH_USER_MODEL, default=1, on_delete=models.CASCADE)
    hostel = models.CharField(blank=True, null=True, default='', max_length=100)
    college = models.CharField(blank=True, null=True, default='', max_length=100, choices=colleges)
    dept = models.ForeignKey(Department, default=3, on_delete=models.CASCADE)
    year_admit = models.DateTimeField(default=datetime.now() + timedelta(minutes=10) - timedelta(hours=1))
    level = models.CharField(blank=True, null=True, default='', max_length=100, choices=levels)
    duration = models.IntegerField(blank=True, null=True, default=0)
    mode_of_study = models.CharField(blank=True, null=True, default=0, max_length=100, choices=choose)

    def __str__(self):
        next1 = '%s %s' % (self.level, self.Registration_No)
        return next1


# For COMPUTER SCIENCE
class CourseReg(models.Model):
    course = models.CharField(max_length=200, default='', null=False, blank=False)
    units = models.IntegerField(default=0)

    def __str__(self):
        return ''.join(map(str, (self.course, self.units)))


SEMESTER = (
    ("1", "1"),
    ("2", "2"),
)


class UploadResult(models.Model):
    student = models.CharField(max_length=100, default='')
    reg_no = models.CharField(max_length=100, default='')
    courses_grade = models.TextField(max_length=1500, default='')
    session = models.CharField(max_length=100, default='')
    semester = models.CharField(choices=SEMESTER, default='', max_length=20)
    year = models.CharField(choices=levels, default='', max_length=20)
    created = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.student
