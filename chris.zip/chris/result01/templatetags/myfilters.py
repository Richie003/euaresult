from django import template
import re

register = template.Library()


@register.filter(safe=True)
def beautify(value):
    # new_value = '<input style="width:50%; height=34px;"'+value[7:]
    # ok = ''.join(new_value)
    print(value[:])
