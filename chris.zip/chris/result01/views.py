from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

# Create your views here.
from django.views.decorators.cache import cache_page
from django.views.decorators.csrf import ensure_csrf_cookie, csrf_protect

from result01.decorators import unauthenticated_user
from result01.forms import CollegeForm, UserAdminCreationForm, CourseForm, CourseRegForm
from .models import College, Dept, UploadResult


def index(request):
    coll = College.objects.all()
    # coll.delete()
    # coll.save()
    form = CollegeForm()
    if request.method == "POST":
        form = CollegeForm(request.POST or None)
        if form.is_valid():
            form.save()
            messages.success(request, "done")
    context = {"form": form}
    return render(request, "home/index.html", context)


# @unauthenticated_user
@ensure_csrf_cookie
@csrf_protect
def register_view(request):
    form = UserAdminCreationForm
    if request.method == 'POST':
        form = UserAdminCreationForm(request.POST or None, request.FILES)
        if form.is_valid():
            user = form.cleaned_data.get('reg_no')
            form.save()
            # sock = Sock_server(username)
            # sock.get_info()
            return redirect('login')

            # template = render_to_string('email/email_to_user.html', {'name': request.user.last_name})
            # email = EmailMessage(
            #     'Thank You For Investing In Me!',
            #     template,
            #     settings.EMAIL_HOST_USER,
            #     [request.user.email]
            # )
            # email.fail_silently = False
            # email.send()

        # template = render_to_string('email/email.html', {'name': request.user.last_name})
        # email = send_mail(
        #     'Thank You For Investing In Me!',
        #     template,
        #     settings.EMAIL_HOST_USER,
        #     [request.user.email]
        # )
        # email.fail_silently = False
        # email.send()

    context = {'form': form}
    return render(request, 'products/add-product.html', context)


@unauthenticated_user
# @cache_page(60 * 9)
@ensure_csrf_cookie
@csrf_protect
def login_page(request):
    if request.method == 'POST':
        reg_no = request.POST.get('reg_no')
        password = request.POST.get('password')

        user = authenticate(request, username=reg_no, password=password)

        if user is not None:
            login(request, user)
            if "next" in request.POST:
                return redirect(request.POST.get("next"))
            else:
                messages.info(request, f'{reg_no} logged in successfully')
                return redirect('home')
        else:
            messages.info(request, 'registration number OR password is incorrect')

    context = {}
    return render(request, 'accounts/login.html', context)


# log_num = rnd(0, 51200)


def log_out(request, pk='first_name'):
    # context={'num':num}
    logout(request)
    return redirect('login')


@login_required(login_url='login')
def results(request):
    user = request.user
    result = UploadResult.objects.all().filter(reg_no=user)
    # result = result.filter(student=user)
    context = {
        "result": result
    }
    return render(request, "tables/table.html", context)


def Course_form(request):
    form = CourseForm
    if request.method == 'POST':
        form = CourseForm(request.POST or None)
        if form.is_valid():
            form.save()
            return redirect('coursereg')
    context = {"form": form}
    return render(request, 'products/courseform.html', context)


def course_reg_form(request):
    form = CourseRegForm
    if request.method == 'POST':
        form = CourseRegForm(request.POST or None)
        if form.is_valid():
            form.save()
            return redirect('coursereg')
    context = {"form": form}
    return render(request, 'products/courseregform.html', context)


def faq(request):
    context = {}
    template = 'FAQS/faq.html'
    return render(request, template, context)
