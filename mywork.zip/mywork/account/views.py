from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.db.models import Q
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import ensure_csrf_cookie, csrf_protect
from .models import *
from .forms import *


# Create your views here.

def index(request):
    context = {}
    return render(request, "index/index.html", context)


# <--All Account Related View-->
# @unauthenticated_user
@ensure_csrf_cookie
@csrf_protect
def register_view(request):
    form = UserAdminCreationForm
    if request.method == 'POST':
        form = UserAdminCreationForm(request.POST or None, request.FILES)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            form.save()
            login(request, user)
            return redirect('login')
    context = {'form': form}
    return render(request, 'accounts/register.html', context)


# @unauthenticated_user
# @cache_page(60 * 9)
# @ensure_csrf_cookie
@csrf_protect
def login_page(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            if "next" in request.POST:
                return redirect(request.POST.get("next"))
            else:
                messages.info(request, f"{username} logged in successfully, you're now a verified customer :) ✔")
                return redirect('home')
        else:
            messages.info(request, 'registration number OR password is incorrect')

    context = {}
    return render(request, 'accounts/login.html', context)


@login_required(login_url='login')
def update_acct(request):
    user = request.user
    form = RegisterForm(instance=user)
    if request.method == 'POST':
        form = RegisterForm(request.POST or None, request.FILES, instance=user)
        if form.is_valid():
            reg_no = request.POST.get('reg_no')
            password = request.POST.get('password')
            first_name = form.cleaned_data.get('first_name')
            last_name = form.cleaned_data.get('last_name')
            user = authenticate(request, username=reg_no, password=password)
            form.save()
            login(request, user)
            messages.info(request, f'dear {first_name} {last_name} your account has been updated successfully')
    context = {'form': form}
    return render(request, 'accounts/profile.html', context)
